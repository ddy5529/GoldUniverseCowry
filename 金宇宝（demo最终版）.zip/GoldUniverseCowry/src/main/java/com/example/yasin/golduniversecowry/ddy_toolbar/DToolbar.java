package com.example.yasin.golduniversecowry.ddy_toolbar;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.example.yasin.golduniversecowry.R;

/**
 * Created by Yasin on 2017/4/12.
 */

public class DToolbar {
    private AppCompatActivity mActivity;
    public DToolbar() {
    }

    public DToolbar(AppCompatActivity context, int mId) {
        this.mActivity=context;
        initToolbar(context,mId);
    }
    private void initToolbar(AppCompatActivity context, int mId) {
        Toolbar toolbar= (Toolbar) context.findViewById(mId);
        toolbar.setBackgroundResource(R.color.colorPrimary);
        context.setSupportActionBar(toolbar);
        ActionBar actionBar=context.getSupportActionBar();
        if (actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
}
