package com.example.yasin.golduniversecowry.getlist;

import com.example.yasin.golduniversecowry.EnactSubListView.MoneyChangerBean;
import com.example.yasin.golduniversecowry.parse_json.ParseUtils;

import java.util.List;

/**
 * Created by Yasin on 2017/3/29.
 */

public class GetFragmentList {
    public List<MoneyChangerBean> getlistMCB(){

        return new ParseUtils().getMoneyChangerBeanList();
    }
}
