package com.example.yasin.golduniversecowry.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yasin.golduniversecowry.EnactSubListView.FriendInfoBean;
import com.example.yasin.golduniversecowry.R;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Yasin on 2017/3/18.
 */

public class FriendInfoRVA extends RecyclerView.Adapter<FriendInfoRVA.ViewHolder>{
    private List<FriendInfoBean> fiblist;
    private View view;
    private ViewHolder viewHolder;

    public FriendInfoRVA(List<FriendInfoBean> fiblist) {
        this.fiblist = fiblist;
    }

    @Override
    public FriendInfoRVA.ViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sub_recyclerview_friendinfo,parent,false);

        viewHolder = new ViewHolder(view);
        viewHolder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(parent.getContext(),"this is friendinfo subview",Toast.LENGTH_SHORT).show();
            }
        });
        init();
        return viewHolder;
    }

    private void init() {
        viewHolder.image.setImageResource(R.mipmap.qizhigirl);
        viewHolder.tv_title.setText(fiblist.get(0).friendname);
        viewHolder.tv_content.setText(fiblist.get(0).friendinfo);
        viewHolder.tv_time.setText(initTime());
    }

    private String initTime() {
        SimpleDateFormat formatter    =   new    SimpleDateFormat    ("yyyy.MM.dd/HH:mm:ss");
        Date curDate    =   new    Date(System.currentTimeMillis());//获取当前时间
        return  formatter.format(curDate);
    }

    @Override
    public void onBindViewHolder(FriendInfoRVA.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return fiblist.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
         RelativeLayout relativeLayout;
         ImageView image;
         TextView tv_title;
         TextView tv_content;
         TextView tv_time;

        public ViewHolder(View itemView) {
            super(itemView);
            relativeLayout= (RelativeLayout) itemView.findViewById(R.id.sub_rc_fdif_relativelayout);
            image = (ImageView) itemView.findViewById(R.id.sub_rc_fdif_imagehead);
            tv_title = (TextView) itemView.findViewById(R.id.sub_rc_fdif_tv_title);
            tv_content = (TextView) itemView.findViewById(R.id.sub_rc_fdif_tv_content);
            tv_time = (TextView) itemView.findViewById(R.id.sub_rc_fdif_tv_time);
        }
    }
}
