package com.example.yasin.golduniversecowry.ElseBean;

import org.litepal.crud.DataSupport;

import java.io.Serializable;

/**
 * Created by Yasin on 2017/3/14.
 */

public class InsuranceBean extends DataSupport implements Serializable{
    private double accrual;//利息
    private String accrual_detail;
    private String commodity_name;
    private String commodity_detail;
    private int InsuranceProductID;

    public InsuranceBean() {
    }

    public double getAccrual() {
        return accrual;
    }

    public void setAccrual(double accrual) {
        this.accrual = accrual;
    }

    public String getAccrual_detail() {
        return accrual_detail;
    }

    public void setAccrual_detail(String accrual_detail) {
        this.accrual_detail = accrual_detail;
    }

    public String getCommodity_name() {
        return commodity_name;
    }

    public void setCommodity_name(String commodity_name) {
        this.commodity_name = commodity_name;
    }

    public String getCommodity_detail() {
        return commodity_detail;
    }

    public void setCommodity_detail(String commodity_detail) {
        this.commodity_detail = commodity_detail;
    }

    public int getInsuranceProductID() {
        return InsuranceProductID;
    }

    public void setInsuranceProductID(int insuranceProductID) {
        InsuranceProductID = insuranceProductID;
    }

    public InsuranceBean(int InsuranceProductID, double accrual, String accrual_detail, String commodity_name, String commodity_detail) {
        this.accrual = accrual;
        this.accrual_detail = accrual_detail;
        this.commodity_name = commodity_name;
        this.commodity_detail = commodity_detail;
        this.InsuranceProductID=InsuranceProductID;
    }

    @Override
    public String toString() {
        return "InsuranceBean{" +
                "accrual=" + accrual +
                ", accrual_detail='" + accrual_detail + '\'' +
                ", commodity_name='" + commodity_name + '\'' +
                ", commodity_detail='" + commodity_detail + '\'' +
                ", InsuranceProductID='" + InsuranceProductID + '\'' +
                '}';
    }
}
