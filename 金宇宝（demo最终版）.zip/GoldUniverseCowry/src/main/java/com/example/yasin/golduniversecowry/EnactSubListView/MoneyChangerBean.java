package com.example.yasin.golduniversecowry.EnactSubListView;

/**
 * Created by Yasin on 2017/3/18.
 */

public class MoneyChangerBean {
    //时间，地点，事件，金额数目
    public String mctime;
    public String mclocation;
    public String mcevent;
    public String mcmoney;
}
