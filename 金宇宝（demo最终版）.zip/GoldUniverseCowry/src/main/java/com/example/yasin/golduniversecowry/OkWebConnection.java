package com.example.yasin.golduniversecowry;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;

import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.FileCallBack;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class OkWebConnection extends AppCompatActivity {
    private final String TAG="Tag";
    public String url="";
    private ProgressBar mprogressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok_web_connection);
        inti();

        new Thread(new Runnable() {
            @Override
            public void run() {
                downloadFile();
                Log.e(TAG, "succeed: :" +readfile());
            }
        }).start();

    }

    private void inti() {
        mprogressBar= (ProgressBar) findViewById(R.id.progressbar);
    }

    public void downloadFile()
    {
//        String url = "http://120.77.170.191/Android_web_Servet1.0/extend.json";
        String url = "http://192.168.1.117:8080/yueqiantest/filminfo.json";
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new FileCallBack(Environment.getExternalStorageDirectory().getAbsolutePath(), "myjson.txt")//FileCallBack(参数一：文件下载下来所存放的目录，参数二：文件下载下来的文件取名)
                {

                    @Override
                    public void onBefore(Request request, int id)
                    {
                    }

                    @Override
                    public void inProgress(float progress, long total, int id)
                    {

                        mprogressBar.setProgress((int) (  progress+15));
//                        Log.e(TAG, "inProgress :" + (int) (100 * progress));
//                        Log.e(TAG, "absolute address :" + Environment.getExternalStorageDirectory().getAbsolutePath());
                    }

                    @Override
                    public void onError(Call call, Exception e, int id)
                    {
                        Log.e(TAG, "onError :" + e.getMessage());
                    }

                    @Override
                    public void onResponse(File file, int id)
                    {
//                        Log.e(TAG, "onResponse :" + file.getAbsolutePath());
                    }
                });
    }
    public String readfile(){
        FileInputStream fileInputStream=null;
        BufferedReader bufferedReader=null;
        StringBuffer stringBuffer=new StringBuffer();
        try {
            File file=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/myjson.txt");
            fileInputStream=new FileInputStream(file);
            bufferedReader=new BufferedReader(new InputStreamReader(fileInputStream));
            String Line="";
            while ((Line=bufferedReader.readLine())!=null){
                stringBuffer.append(Line);
            };
        }catch (Exception e){
            Log.e(TAG, "file read Error ---------" + e.getMessage());

        }finally {
            try {
                if (bufferedReader!=null) {
                    bufferedReader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return stringBuffer.toString();
    }
}
