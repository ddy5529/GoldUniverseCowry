package com.example.yasin.golduniversecowry.sql;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by Yasin on 2017/4/13.
 */

public class UserDBManager {
    MyDatabaseHelper helper;
    SQLiteDatabase db;
    Cursor cursor;

    public UserDBManager() {
    }

    public Cursor returnUserTableCursor(Context context){
        helper=new MyDatabaseHelper(context,"User.db",null,4);
        db= helper.getWritableDatabase();
        cursor=db.query("UserTable",null,null,null,null,null,null);
        return cursor;
    }
    public void closeUserTableDB(){
        cursor.close();
        db.close();
        helper.close();
    }
}
