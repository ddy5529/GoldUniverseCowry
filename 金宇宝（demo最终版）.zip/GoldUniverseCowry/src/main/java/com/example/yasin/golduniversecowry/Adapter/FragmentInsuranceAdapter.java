package com.example.yasin.golduniversecowry.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.yasin.golduniversecowry.R;
import com.example.yasin.golduniversecowry.fragment.ImageFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yasin on 2017/3/30.
 */

public class FragmentInsuranceAdapter extends FragmentPagerAdapter {
    List<Fragment> list;
    List<String> title=new ArrayList<>();


    public FragmentInsuranceAdapter(FragmentManager fm,List<Fragment> list) {
        super(fm);
        this.list=list;
        for(Fragment f:list){
            title.add("图片"+((ImageFragment)f).title);
        }
    }

    @Override
    public Fragment getItem(int position) {
        return list.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return title.get(position);
    }

    @Override
    public int getCount() {
        return list==null||list.isEmpty()?0:list.size();
    }

}
