package com.example.yasin.golduniversecowry.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

import com.example.yasin.golduniversecowry.R;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

/**
 * Created by Yasin on 2017/3/28.
 */

public class zhxRecycleAdpater<String> extends CommonAdapter<String> {

    public zhxRecycleAdpater(Context context, int layoutId, List<String> datas) {
        super(context, layoutId, datas);
    }

    @Override
    protected void convert(ViewHolder holder, String moneyChangerBean, int position) {

        holder.setText(R.id.id_item_list_title,"张三");
    }


}
