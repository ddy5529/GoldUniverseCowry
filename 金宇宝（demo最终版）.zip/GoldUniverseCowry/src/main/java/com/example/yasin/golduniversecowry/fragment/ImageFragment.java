package com.example.yasin.golduniversecowry.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.yasin.golduniversecowry.R;

import java.util.zip.Inflater;

/**
 * Created by Yasin on 2017/3/30.
 */

public class ImageFragment extends Fragment {
    private ImageView imageView;
    public String title="图片n";
    private int ImageId;
    private View view;

    public ImageFragment() {
    }

    public ImageFragment(String title, int imageId) {
        this.title = title;
        ImageId = imageId;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e("Tag",ImageFragment.class+"碎片的初始化中......");
        view=inflater.inflate(R.layout.framentimage,container,false);
        Log.e("Tag",ImageFragment.class+"view加载成功");
        imageView = (ImageView) view.findViewById(R.id.fragment_image_iv);
        Log.e("Tag",ImageFragment.class+"图片初始化中");
        imageView.setImageResource(ImageId);
        Log.e("Tag",ImageFragment.class+"图片初始化完成");
        return view;
    }

}
