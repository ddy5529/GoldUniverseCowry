package com.example.yasin.golduniversecowry.Activitys;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yasin.golduniversecowry.R;
import com.example.yasin.golduniversecowry.ddy_toolbar.DToolbar;
import com.example.yasin.golduniversecowry.sql.MyDatabaseHelper;

import butterknife.BindView;
import butterknife.ButterKnife;

public class UserRegistActivity extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.activity_uset_regist_toolbar)
    Toolbar activityUsetRegistToolbar;
    @BindView(R.id.activity_uset_regist_username)
    EditText activityUsetRegistUsername;
    @BindView(R.id.activity_uset_regist_password)
    EditText activityUsetRegistPassword;
    @BindView(R.id.activity_uset_regist_again_password)
    EditText activityUsetRegistAgainPassword;
    @BindView(R.id.activity_uset_regist_question)
    EditText activityUsetRegistQuestion;
    @BindView(R.id.activity_uset_regist_answer)
    EditText activityUsetRegistAnswer;
    @BindView(R.id.activity_uset_regist_bt_empty)
    Button activityUsetRegistBtEmpty;
    @BindView(R.id.activity_uset_regist_bt_submit)
    Button activityUsetRegistBtSubmit;
    @BindView(R.id.activity_uset_regist)
    LinearLayout activityUsetRegist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uset_regist);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        initToolbar();
        initControl();
    }

    private void initToolbar() {
        //初始化toolbar
        new DToolbar(this, R.id.activity_uset_regist_toolbar);
    }

    private void initControl() {
        activityUsetRegistBtEmpty.setOnClickListener(this);
        activityUsetRegistBtSubmit.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.activity_uset_regist_bt_empty:
                activityUsetRegistUsername.setText("");
                activityUsetRegistPassword.setText("");
                activityUsetRegistAgainPassword.setText("");
                activityUsetRegistQuestion.setText("");
                activityUsetRegistAnswer.setText("");
                break;
            case R.id.activity_uset_regist_bt_submit:
                if (activityUsetRegistAgainPassword.getText().toString().trim().equals(
                    activityUsetRegistPassword.getText().toString().trim()
                )){
                    //输入的密码一致
                   String username= activityUsetRegistUsername.getText().toString().trim();
                   String password= activityUsetRegistPassword.getText().toString().trim();
                   String question= activityUsetRegistQuestion.getText().toString().trim();
                   String answer= activityUsetRegistAnswer.getText().toString().trim();
                    Log.e("Tag",UserRegistActivity.class+"|"+username+"|");
                    Log.e("Tag",UserRegistActivity.class+"|"+password+"|");
                    Log.e("Tag",UserRegistActivity.class+"|"+question+"|");
                    Log.e("Tag",UserRegistActivity.class+"|"+answer+"|");
                    MyDatabaseHelper helper=new MyDatabaseHelper(this,"User.db",null,4);
                    SQLiteDatabase db= helper.getWritableDatabase();
                    ContentValues values=new ContentValues();
                    values.put("username",username);
                    values.put("password",password);
                    values.put("question",question);
                    values.put("answer",answer);
                    values.put("money",0f);
                    db.insert("UserTable",null,values);
                    //查询数据库
//                    Cursor cursor=db.query("UserTable",null,null,null,null,null,null);
//                    if (cursor.moveToFirst()){
//                        do {
//                            Log.e("Tag","-----|"+cursor.getString(cursor.getColumnIndex("username"))+"|-----");
//                            Log.e("Tag","-----|"+cursor.getString(cursor.getColumnIndex("password"))+"|-----");
//                            Log.e("Tag","-----|"+cursor.getString(cursor.getColumnIndex("question"))+"|-----");
//                            Log.e("Tag","-----|"+cursor.getString(cursor.getColumnIndex("answer"))+"|-----");
//                        }while (cursor.moveToNext());
//                    }
                    //关闭
                    values.clear();
                    db.close();
                    helper.close();
                    finish();
                }else {
                    Toast.makeText(this,"两次密码输入不一致",Toast.LENGTH_SHORT).show();
                    activityUsetRegistPassword.setText("");
                    activityUsetRegistAgainPassword.setText("");
                }

                break;
        }
    }
}
