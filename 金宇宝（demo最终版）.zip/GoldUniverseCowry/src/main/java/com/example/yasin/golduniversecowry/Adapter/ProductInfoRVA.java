package com.example.yasin.golduniversecowry.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.yasin.golduniversecowry.EnactSubListView.ProductInfoBean;
import com.example.yasin.golduniversecowry.R;

import java.util.List;

/**
 * Created by Yasin on 2017/3/18.
 */

public class ProductInfoRVA extends RecyclerView.Adapter<ProductInfoRVA.ViewHolder> {
    private List<ProductInfoBean> fiblist;

    public ProductInfoRVA(List<ProductInfoBean> fiblist) {
        this.fiblist = fiblist;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.sub_recyclerview_productinfo,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.image.setImageResource(R.mipmap.logoko1);
        holder.tv1.setText(fiblist.get(0).PDIname);
        holder.tv2.setText(fiblist.get(0).PDIinfo);

    }

    @Override
    public int getItemCount() {
        return fiblist.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout relativeLayout;
        TextView tv1,tv2;
        ImageView image;
        public ViewHolder(View itemView) {
            super(itemView);
            relativeLayout= (RelativeLayout) itemView.findViewById(R.id.sub_rc_pdif_relativelayout);
            tv1= (TextView) itemView.findViewById(R.id.sub_rc_pdif_tv_title);
            tv2= (TextView) itemView.findViewById(R.id.sub_rc_pdif_tv_content);
            image= (ImageView) itemView.findViewById(R.id.sub_rc_pdif_image);
        }
    }
}
