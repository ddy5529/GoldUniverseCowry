package com.example.yasin.golduniversecowry.fragment;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.annotation.RequiresApi;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.yasin.golduniversecowry.Adapter.ContactListViewAdpater;
import com.example.yasin.golduniversecowry.Adapter.FragmentInsuranceAdapter;
import com.example.yasin.golduniversecowry.ElseBean.InsuranceBean;
import com.example.yasin.golduniversecowry.R;
import com.viewpagerindicator.TabPageIndicator;

import org.litepal.crud.DataSupport;
import org.litepal.tablemanager.Connector;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yasin on 2017/2/20.
 */
//第一个页面
public class InsuranceFragment extends Fragment {
    private View view;
    private List<InsuranceBean> clv = new ArrayList<>();
    private Thread thread;
    public boolean inRunAble;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initData();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_insurance, container, false);
        initVP();
        initContactsFragment();
        return view;
    }

    private void initVP() {
        //图片轮播器
        final List<Fragment> list=new ArrayList<>();
        list.add(new ImageFragment("人头",R.mipmap.a1006));
        list.add(new ImageFragment("音乐",R.mipmap.a1007));
        list.add(new ImageFragment("聊天",R.mipmap.a1009));
        list.add(new ImageFragment("女孩",R.mipmap.qizhigirl));
        FragmentInsuranceAdapter adapter = new FragmentInsuranceAdapter(getFragmentManager(),list);
        final ViewPager pager = (ViewPager) view.findViewById(R.id.fragment_insurance_vp_product);
        pager.setAdapter(adapter);
        TabPageIndicator indicator = (TabPageIndicator) view.findViewById(R.id.fragment_insurance_tpi_product);
        indicator.setViewPager(pager);
        final Handler hand=new Handler(){
            public void handleMessage(Message msg){
                int currentItem= (int) msg.obj;
                pager.setCurrentItem(currentItem%list.size());
            }
        };
        thread = new Thread(new Runnable() {
             boolean inRunAble=true;
             @Override
             public void run() {
                while (inRunAble){
                    try {
                        Thread.sleep(3000);
                        Message msg=hand.obtainMessage();
                        int curr=pager.getCurrentItem();
                        curr++;
                        msg.obj=curr;
                        hand.sendMessage(msg);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
             }
         });
        thread.start();
    }

    private void initData() {
        double k1 = 4.20;
        InsuranceBean cl1 = new InsuranceBean(1, k1, "业绩比较基准", "齐鲁稳固84天9号", "卷商出品|限时抢购");
        clv.add(cl1);
        double k2 = 5.60;
        InsuranceBean cl2 = new InsuranceBean(1, k2, "历史年化结算利息", "渤海5年期", "100起购|首年赠2%");
        clv.add(cl2);
        double k3 = 5.20;
        InsuranceBean cl3 = new InsuranceBean(2, k3, "预期年化收益率", "理财期限 30天", "爆品资产 先到先得");
        clv.add(cl3);
        double k4 = 4.80;
        InsuranceBean cl4 = new InsuranceBean(1, k4, "预期年化收益率", "理财期限 灵活领取", "固收精选 灵活配置");
        clv.add(cl4);
        double k5 = 5.20;
        InsuranceBean cl5 = new InsuranceBean(1, k5, "历史年化结算利率", "一年后无领取费用", "学知识加送0.70%一年收益");
        clv.add(cl5);
        double k6 = 5.50;
        InsuranceBean cl6 = new InsuranceBean(1, k6, "历史年化回报率", "每满两年可免费退保", "买定期理财享资产奖励");
        clv.add(cl6);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initContactsFragment() {
        RecyclerView recyc = (RecyclerView) view.findViewById(R.id.insurance_recyclerview1_id);
        LinearLayoutManager llm = new LinearLayoutManager(view.getContext());
        recyc.setLayoutManager(llm);
        /*SimpleDateFormat    formatter    =   new    SimpleDateFormat    ("yyyy.MM.dd/HH:mm:ss");
        Date    curDate    =   new    Date(System.currentTimeMillis());//获取当前时间
        String    str    =    formatter.format(curDate);//获取时间*/
        ContactListViewAdpater adpater = new ContactListViewAdpater(clv);
        recyc.setAdapter(adpater);
        recyc.setItemAnimator(new DefaultItemAnimator());
        recyc.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.HORIZONTAL));

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        inRunAble=false;
    }
}

//        Connector.getDatabase();
//if(!cl1.isSaved()){
//
//        以下两家代码表示 the two code stand for meet condition,set accrual for 4.32,else don't do anything
//        cl1.setAccrual(4.32);
//        cl1.updateAll("accrual = ? and accrual_detail = ?","4.20","业绩比较基准");
//        delete sql_lite_pal the data,below is code:
//        DataSupport.deleteAll(InsuranceBean.class," InsuranceProductID < ? ","4");
//
//
//        select sql_lite_pal data
//        List<InsuranceBean>list=DataSupport.findAll(InsuranceBean.class);
//
//
//        cl1.save();
//        }