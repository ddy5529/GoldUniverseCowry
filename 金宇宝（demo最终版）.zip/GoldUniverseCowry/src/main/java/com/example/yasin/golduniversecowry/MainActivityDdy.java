package com.example.yasin.golduniversecowry;

import android.annotation.TargetApi;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.FileProvider;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.example.yasin.golduniversecowry.Activitys.AllTheIndentActivity;
import com.example.yasin.golduniversecowry.Activitys.LoginActivity;
import com.example.yasin.golduniversecowry.Services.Broadcast_Service;
import com.example.yasin.golduniversecowry.fragment.FundFragment;
import com.example.yasin.golduniversecowry.fragment.InsuranceFragment;
import com.example.yasin.golduniversecowry.fragment.LoanFragment;
import com.example.yasin.golduniversecowry.fragment.ProfileFragment;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivityDdy extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, ViewPager.OnPageChangeListener,NavigationView.OnNavigationItemSelectedListener {
    private static final int TAKE_PHOTO = 1;
    private RadioButton rb_radioButton[] = new RadioButton[4];
    private Drawable drawable[] = new Drawable[4];
    private RadioGroup radiogroup;
    private ViewPager viewpager;
    private Toolbar toolbar;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;
    private Uri imageUri;
//    private DrawerLayout drawerLayout;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);//关闭标题
        setContentView(R.layout.activity_main_ddy);
        init();
        initToolbar();
        initViewPage();
        initRB();
        initServer();
        initNavigationView();
//        Log.e("Tag","MA---- onCreate ");
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    //初始化侧边菜单栏的内容
    private void initNavigationView() {
        NavigationView navigationView= (NavigationView) MainActivityDdy.this.findViewById(R.id.nav_view);
//        navigationView.setCheckedItem(R.id.nav_camera);
//       Log.e("Tag", navigationView.getHeaderView(0).toString());
        final LinearLayout side_drawerlayout_linear= (LinearLayout)  navigationView.getHeaderView(0).findViewById(R.id.activity_side_drawerlayout_linearlayout);
        final TextView sideusername = (TextView) navigationView.getHeaderView(0).findViewById(R.id.activity_side_drawerlayout_name);
        final TextView sideusermoney= (TextView) navigationView.getHeaderView(0).findViewById(R.id.activity_side_drawerlayout_money);
        side_drawerlayout_linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ProfileFragment.isLogin){
                    sideusername.setText(ProfileFragment.pro_username);
                    sideusermoney.setText(ProfileFragment.pro_money);
                    side_drawerlayout_linear.setVisibility(View.GONE);
                }else {
                    Intent intent=new Intent(MainActivityDdy.this, LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.nav_AllTheIndent:
                        Intent intent=new Intent(MainActivityDdy.this,AllTheIndentActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.nav_manage:
                        //个人设置
                        break;
                }

                return false;
            }
        });
    }

    private void initServer() {
        Intent server_intent=new Intent(this, Broadcast_Service.class);
        startService(server_intent);
    }

    private void initToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.ddy_drawerlayout_id);
        //设置actionbar的抽屉开关
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();


    }

    @Override
    protected void onPause() {//按返回键时启动该生命周期，另一个活动来到前台时启动这个方法（暂停)
        super.onPause();
    }

    //菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.scan_QR_Code:
                openCamera();
                Toast.makeText(this, "打开照相机扫描二维码", Toast.LENGTH_SHORT).show();
                break;
            case R.id.test:
                Toast.makeText(this, "菜单按钮测试", Toast.LENGTH_SHORT).show();
                SmsManager smsManager=SmsManager.getDefault();
                smsManager.sendTextMessage("17736605830",null,"我是jyb菜单text",null,null);
                Toast.makeText(MainActivityDdy.this,"发送成功",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sharp:

                break;
            case R.id.ruby:
                SimpleDateFormat formatter=new SimpleDateFormat    ("yyyy.MM.dd/HH:mm:ss");
                Date curDate =new Date(System.currentTimeMillis());//获取当前时间
                String str = formatter.format(curDate);//获取时间
                Snackbar.make(this.getCurrentFocus(),str,Snackbar.LENGTH_LONG).setAction("Undo", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivityDdy.this,"时间",Toast.LENGTH_SHORT).show();
                    }
                }).show();
                break;
            case R.id.menu_exit:
                finish();
                break;
        }
        return true;
    }

    //打开照相机
    private void openCamera() {
        //在关联缓存目录下存放图片，在sdcard/android/data/<package name>/cache下
        File outputImage=new File(getExternalCacheDir(),"output_image.jpg");
        try {
            if(outputImage.exists()){
                outputImage.delete();
            }
            outputImage.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(Build.VERSION.SDK_INT>=24){
            imageUri = FileProvider.getUriForFile(MainActivityDdy.this,"com.example.yasin.golduniversecowry",outputImage);
        }else {
             imageUri=Uri.fromFile(outputImage);
        }
        Intent intent=new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra(MediaStore.EXTRA_OUTPUT,imageUri);
        startActivityForResult(intent,TAKE_PHOTO);
    }

    //在返回activity的结果集时,加载拍照得到的相片
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode){
            case TAKE_PHOTO:{
                if (resultCode == RESULT_OK) {
                    try {
                        Bitmap bitmap= BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                        //在这里设置图片
//                        Glide.with(this)
//                                .load(bitmap)
//                                .into();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }


    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
//        startActivity(new Intent((this, NewActivity.class)));
        return false;

    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void init() {
        rb_radioButton[0] = (RadioButton) findViewById(R.id.rb_insurance);
        drawable[0] = getDrawable(R.drawable.rb_insurance_selector);//设置底部菜单栏的图片选择器
        drawable[0].setBounds(0, 0, 77, 55);//设置的是底部按钮的长和宽。
        rb_radioButton[0].setCompoundDrawables(null, drawable[0], null, null);

        rb_radioButton[1] = (RadioButton) findViewById(R.id.rb_loan);
        drawable[1] = getDrawable(R.drawable.rb_loan_selector);
        drawable[1].setBounds(0, 0, 77, 55);
        rb_radioButton[1].setCompoundDrawables(null, drawable[1], null, null);

        rb_radioButton[2] = (RadioButton) findViewById(R.id.rb_fund);
        drawable[2] = getDrawable(R.drawable.rb_fund_selector);
        drawable[2].setBounds(0, 0, 77, 55);////第一0是距左边距离，第二0是距上边距离，40分别是长宽
        rb_radioButton[2].setCompoundDrawables(null, drawable[2], null, null);//设置左，上，右，下（顺时针）方向的图片

        rb_radioButton[3] = (RadioButton) findViewById(R.id.rb_profile);
        drawable[3] = getDrawable(R.drawable.rb_my_selector);
        drawable[3].setBounds(0, 0, 77, 55);
        rb_radioButton[3].setCompoundDrawables(null, drawable[3], null, null);
        radiogroup = (RadioGroup) findViewById(R.id.radiogroup1);
        viewpager = (ViewPager) findViewById(R.id.second_viewpager_id01);

        toolbar = (Toolbar) findViewById(R.id.toolbar);

    }//初始化组件

    private void initRB() {
        //初始化选择的按钮
        rb_radioButton[0].setChecked(true);
        rb_radioButton[0].setTextColor(getResources().getColor(R.color.Blue_green));
        radiogroup.setOnCheckedChangeListener(this);
    }//RB方法

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {//当切换按钮选项是触发
        switch (i) {
            case R.id.rb_insurance:
                viewpager.setCurrentItem(0);//第二个参数设置成false是取消滑动，不设置或者设置true是滑动。
                rb_radioButton[0].setTextColor(getResources().getColor(R.color.Blue_green));
                rb_radioButton[1].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[2].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[3].setTextColor(getResources().getColor(R.color.colorgray));
                break;
            case R.id.rb_loan:
//                Toast.makeText(context,"find",Toast.LENGTH_SHORT).show();
                viewpager.setCurrentItem(1);
                rb_radioButton[0].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[1].setTextColor(getResources().getColor(R.color.colorBlue));
                rb_radioButton[2].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[3].setTextColor(getResources().getColor(R.color.colorgray));
                break;
            case R.id.rb_fund:
                viewpager.setCurrentItem(2);
                rb_radioButton[0].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[1].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[2].setTextColor(getResources().getColor(R.color.golden));
                rb_radioButton[3].setTextColor(getResources().getColor(R.color.colorgray));
                break;
            case R.id.rb_profile:
                viewpager.setCurrentItem(3);
                rb_radioButton[0].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[1].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[2].setTextColor(getResources().getColor(R.color.colorgray));
                rb_radioButton[3].setTextColor(getResources().getColor(R.color.orange));
                break;
//            default:
//                Toast.makeText(MainActivityDdy.this,"没选择上",Toast.LENGTH_SHORT).show();
//                break;
        }
    }//点击按钮时的监听器

    //viewPage切换时的操作
    private void initViewPage() {
        viewpager.setAdapter(new A(getSupportFragmentManager(), getDate()));//给viewpager设置一个适配器
        viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {//切换fragment时触发
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                for (int i = 0; i < 4; i++) {
                    rb_radioButton[i].setTextColor(getResources().getColor(R.color.colorgray));//
                }
                rb_radioButton[position].setChecked(true);
                switch (position) {
                    case 0:
                        rb_radioButton[position].setTextColor(getResources().getColor(R.color.Blue_green));
                        break;
                    case 1:
                        rb_radioButton[position].setTextColor(getResources().getColor(R.color.colorBlue));
                        break;
                    case 2:
                        rb_radioButton[position].setTextColor(getResources().getColor(R.color.golden));
                        break;
                    case 3:
                        rb_radioButton[position].setTextColor(getResources().getColor(R.color.orange));
                        break;
                }

//                Log.e("Tag",position+" ");
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }//ViewPager的定义

    private List<Fragment> date = new ArrayList<>();
    public List<Fragment> getDate() {
        //理财，贷款，推荐，我
        date.add(new InsuranceFragment());
        date.add(new LoanFragment());
        date.add(new FundFragment());
        date.add(new ProfileFragment());
        return date;
    }

    //viewpage的动作监听器
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    /**
     * 这是AS自动生成的工具类app
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("MainActivityDdy Page")
                // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }

    //Toolbar的菜单选项栏
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_camera:
                Log.d("Tag","菜单相机");
                openCamera();
                break;
            case R.id.nav_gallery:
                Toast.makeText(this, "nav_gallery", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_manage:
                break;
            case R.id.nav_share:
                break;
            case R.id.nav_send:
                break;
        }
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.ddy_drawerlayout_id);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    class A extends FragmentPagerAdapter {  //定义了一个Fragment的pager的适配器
        private List<Fragment> list;

        public A(FragmentManager fm, List<Fragment> list) {
            super(fm);
            this.list = list;
        }

        @Override//得到条目的数目
        public int getCount() {
            return list == null || list.isEmpty() ? 0 : list.size();
        }


        @Override
        public Fragment getItem(int position) {
            //返回一个fragment对象
            return list.get(position);
            /*
            用v4包不能调用FragmentManager fragmentManager = getFragmentManager();
            用正常包无法返回Fragment对象
            */
        }
    }//内部类A结束，是Viewpage的适配器

}//all
