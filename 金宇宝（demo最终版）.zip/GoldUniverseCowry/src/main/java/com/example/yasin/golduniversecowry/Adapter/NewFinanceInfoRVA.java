package com.example.yasin.golduniversecowry.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.yasin.golduniversecowry.EnactSubListView.NewFinanceInfoBean;
import com.example.yasin.golduniversecowry.R;

import java.util.List;

/**
 * Created by Yasin on 2017/3/18.
 */

public class NewFinanceInfoRVA extends RecyclerView.Adapter<NewFinanceInfoRVA.ViewHolder>{
    private List<NewFinanceInfoBean> fiblist;

    public NewFinanceInfoRVA(List<NewFinanceInfoBean> fiblist) {
        this.fiblist = fiblist;
    }

    @Override
    public NewFinanceInfoRVA.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.sub_recyclerview_newfinanceinfo,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(NewFinanceInfoRVA.ViewHolder holder, int position) {
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.tv1.setText(fiblist.get(0).NFItitle);
        holder.tv2.setText(fiblist.get(0).NFIcontent);
    }

    @Override
    public int getItemCount() {
        return fiblist.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout relativeLayout;
        TextView tv1,tv2;
        public ViewHolder(View itemView) {
            super(itemView);
            relativeLayout= (RelativeLayout) itemView.findViewById(R.id.sub_rc_nfcif_relativelayout);
            tv1= (TextView) itemView.findViewById(R.id.sub_rc_nfcif_tv_title);
            tv2= (TextView) itemView.findViewById(R.id.sub_rc_nfcif_tv_content);
        }
    }
}
