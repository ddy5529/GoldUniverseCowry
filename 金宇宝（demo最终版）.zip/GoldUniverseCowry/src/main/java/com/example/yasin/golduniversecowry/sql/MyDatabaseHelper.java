package com.example.yasin.golduniversecowry.sql;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * Created by Yasin on 2017/4/13.
 */

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static final String CREATE_UserInfo="create table UserTable( " +
            "id integer primary key autoincrement, " +
            "username text, " +
            "password text, " +
            "question text, " +
            "answer text ," +
            "money real" +
            ")";
    public static final String CREATE_UserBuy="create table UserBuy( " +
            "id integer primary key autoincrement, " +
            "product_name text, " +
            "price real, " +
            "time text " +
            "）" ;
    public static final String CREATE_UserLend="create table UserLend( " +
            "id integer primary key autoincrement, " +
            "lend_name text, " +
            "price real, " +
            "time text " +
            "）" ;
    private final Context mContext;

    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_UserInfo);
        db.execSQL(CREATE_UserBuy);
        db.execSQL(CREATE_UserLend);

        Toast.makeText(mContext,"Create succeed UserInfo",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists UserTable");
        onCreate(db);
    }
    MyDatabaseHelper helper;
    SQLiteDatabase db;
    Cursor cursor;
    public Cursor returnUserTableCursor(Context context){
        helper=new MyDatabaseHelper(context,"User.db",null,4);
        db= helper.getWritableDatabase();
        cursor=db.query("UserTable",null,null,null,null,null,null);
        return cursor;
    }
    public void colseUserTableDB(){
        cursor.close();
        db.close();
        helper.close();
    }
}
