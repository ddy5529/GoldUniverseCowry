package com.example.yasin.golduniversecowry.litepal_database;

/**
 * Created by Yasin on 2017/4/7.
 */

public class LitePalControl {

    public void CreatedLitePal(String formsname ){
        //根据表名来创建表单
    }

    //根据传入的值插入数据
    public void InsertLitePal(String operation){

    }
    public void UpdataLitePal(String operation){
        //对象.updataAll();---->p239
    }

    public void DeleteLitePal(String operation){
    }

    public void SelecteLitePal(String operation){

    }

    public void EditLitePal(String operation){

    }

}
