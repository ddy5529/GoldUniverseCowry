package com.example.yasin.golduniversecowry.web_connection;

import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Created by Yasin on 2017/3/20.
 */

public class WebConnection {
    public WebConnection() {
    }
    public void newConnection(String webaddress){
        OkHttpUtils
                .get()
                .url(webaddress)
                .build()
                .execute(new MyStringCallBack());
    }
    class MyStringCallBack extends StringCallback{

        @Override
        public void onError(Call call, Exception e, int id) {

        }

        @Override
        public void onResponse(String response, int id) {
            //解析数据
        }
    }
}
