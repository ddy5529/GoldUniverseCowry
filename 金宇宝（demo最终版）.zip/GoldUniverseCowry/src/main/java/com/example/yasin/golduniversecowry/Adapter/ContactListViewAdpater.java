package com.example.yasin.golduniversecowry.Adapter;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yasin.golduniversecowry.Activitys.BuyGoldProductActivity;
import com.example.yasin.golduniversecowry.ElseBean.InsuranceBean;
import com.example.yasin.golduniversecowry.R;

import java.util.List;

/**
 * Created by Yasin on 2017/2/22.
 */

public class ContactListViewAdpater extends RecyclerView.Adapter<ContactListViewAdpater.ViewHolder> {
    private List<InsuranceBean> mCLV_List;

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView1, textView2, textView3, textView4;
        RelativeLayout relativeLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            relativeLayout = (RelativeLayout) itemView.findViewById(R.id.goods_relativelayout);
            textView1 = (TextView) itemView.findViewById(R.id.goods_accrual);
            textView2 = (TextView) itemView.findViewById(R.id.goods_accrual_detail);
            textView3 = (TextView) itemView.findViewById(R.id.goods_commodity_name);
            textView4 = (TextView) itemView.findViewById(R.id.goods_commodity_detail);
        }
    }

    public ContactListViewAdpater(List<InsuranceBean> contactListViews) {
        mCLV_List = contactListViews;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contactlistview, parent, false);
        final ViewHolder viewHolder = new ViewHolder(view);

        viewHolder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //viewHolder的点击事件
//                Toast.makeText(view.getContext(), "你点击的是第: " + viewHolder.getAdapterPosition() + " 条信息 ", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(view.getContext(), BuyGoldProductActivity.class);
                //传值给下一个特定的Intent对象
                //传当前list的条目位置中所存储的数据
                intent.putExtra("Gold_Product_Accrual", mCLV_List.get(viewHolder.getAdapterPosition()).getAccrual());
                intent.putExtra("Gold_Product_Accrual_Detail", mCLV_List.get(viewHolder.getAdapterPosition()).getAccrual_detail());
                intent.putExtra("Gold_Product_Commodity_Name", mCLV_List.get(viewHolder.getAdapterPosition()).getCommodity_name());
                intent.putExtra("Gold_Product_Commodity_Detail", mCLV_List.get(viewHolder.getAdapterPosition()).getCommodity_detail());
                view.getContext().startActivity(intent);
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Log.e("Tag"," bind position "+position);
        InsuranceBean insuranceBean = mCLV_List.get(position);
        if(insuranceBean!=null) {
            holder.textView1.setText(String.valueOf(insuranceBean.getAccrual()));//accrual
            holder.textView2.setText(insuranceBean.getAccrual_detail());//accrual_detail
            holder.textView3.setText(insuranceBean.getCommodity_name());//commodity_name
            holder.textView4.setText(insuranceBean.getCommodity_detail());//commodity_detail
        }
    }

    @Override
    public int getItemCount() {
        return mCLV_List.size();
    }
}
