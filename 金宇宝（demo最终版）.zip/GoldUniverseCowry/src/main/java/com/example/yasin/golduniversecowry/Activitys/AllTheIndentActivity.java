package com.example.yasin.golduniversecowry.Activitys;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;

import com.example.yasin.golduniversecowry.Adapter.ContactListViewAdpater;
import com.example.yasin.golduniversecowry.ElseBean.InsuranceBean;
import com.example.yasin.golduniversecowry.R;
import com.example.yasin.golduniversecowry.ddy_toolbar.DToolbar;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

//订单？
public class AllTheIndentActivity extends AppCompatActivity {

    @BindView(R.id.activity_all_the_indent_recycler)
    RecyclerView activityAllTheIndentRecycler;
    public static List<InsuranceBean> list= new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_the_indent);
        //这是个啥
        ButterKnife.bind(this);
        initData();
        init();
    }

    private void initData() {
//        从数据库中取出数据给List<InsuranceBean>
    }

    @Override
    protected void onStart() {
        Log.e("Tag","AllTheIndentActivity is start");
        super.onStart();
        Intent intent=getIntent();
        //获取一个bean实例化成serializable的对象。
        InsuranceBean bean= (InsuranceBean) intent.getSerializableExtra("Serializable");
        list.add(bean);
//        list.notifyAll();
    }

    private void init() {
        activityAllTheIndentRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        activityAllTheIndentRecycler.setAdapter(new ContactListViewAdpater(list));
        activityAllTheIndentRecycler.setItemAnimator(new DefaultItemAnimator());
        activityAllTheIndentRecycler.addItemDecoration(new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.HORIZONTAL));
        new DToolbar(this,R.id.activity_all_the_indent_toolbar);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

}
