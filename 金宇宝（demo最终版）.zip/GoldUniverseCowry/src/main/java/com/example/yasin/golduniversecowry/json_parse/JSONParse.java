package com.example.yasin.golduniversecowry.json_parse;

/**
 * Created by Yasin on 2017/3/20.
 */

public class JSONParse {
}
