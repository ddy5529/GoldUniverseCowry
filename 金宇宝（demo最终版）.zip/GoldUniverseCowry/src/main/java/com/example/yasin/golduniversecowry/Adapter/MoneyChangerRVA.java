package com.example.yasin.golduniversecowry.Adapter;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.yasin.golduniversecowry.EnactSubListView.MoneyChangerBean;
import com.example.yasin.golduniversecowry.R;

import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by Yasin on 2017/3/18.
 */

public class MoneyChangerRVA extends RecyclerView.Adapter<MoneyChangerRVA.ViewHolder> {
    private List<MoneyChangerBean> fiblist;
    static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout relativeLayout;
       TextView tv_time,tv_location,tv_event,tv_money;

        public ViewHolder(View itemView) {
            super(itemView);
            relativeLayout= (LinearLayout) itemView.findViewById(R.id.sub_rc_mc_linearLayout);
            tv_time= (TextView) itemView.findViewById(R.id.sub_rc_mc_tv_time);
            tv_location= (TextView) itemView.findViewById(R.id.sub_rc_mc_tv_location);
            tv_event= (TextView) itemView.findViewById(R.id.sub_rc_mc_tv_event);
            tv_money= (TextView) itemView.findViewById(R.id.sub_rc_mc_tv_money);
        }
    }

    public MoneyChangerRVA(List<MoneyChangerBean> fiblist) {
        this.fiblist = fiblist;
        Log.e("Tag","MoneyChangerRVA构造器初始化成功");
    }

    @Override
    public MoneyChangerRVA.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.e("Tag","MoneyChangerRVA适配器onCreateViewHolder创建成功");
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sub_recyclerview_moneychange,parent,false));
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public void onBindViewHolder(MoneyChangerRVA.ViewHolder holder, int position) {
        holder.tv_time.setText(fiblist.get(position).mctime);
        holder.tv_location.setText(fiblist.get(position).mclocation);
        holder.tv_event.setText(fiblist.get(position).mcevent);
        holder.tv_money.setText(fiblist.get(position).mcmoney);
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return fiblist.size();
    }


}
