package com.example.yasin.golduniversecowry.BroadCaseReceiver_ddy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by Yasin on 2017/2/24.
 */

public class NormalBroadReceiver extends BroadcastReceiver {//广播接收器
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context,"这是一个大消息",Toast.LENGTH_SHORT).show();
    }
}
