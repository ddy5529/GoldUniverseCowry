package com.example.yasin.golduniversecowry.EnactSubListView;

/**
 * Created by Yasin on 2017/3/18.
 */

public class FriendInfoBean {
    //朋友，时间，发送的信息，图片
    public String friendname;
    public String friendtime;
    public String friendinfo;
    public String friendphoto;
}
