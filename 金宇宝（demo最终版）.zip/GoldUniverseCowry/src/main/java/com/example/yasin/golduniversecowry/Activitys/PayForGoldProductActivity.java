package com.example.yasin.golduniversecowry.Activitys;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.yasin.golduniversecowry.ElseBean.InsuranceBean;
import com.example.yasin.golduniversecowry.R;
import com.example.yasin.golduniversecowry.ddy_toolbar.DToolbar;

import butterknife.BindView;
import butterknife.ButterKnife;

//付款界面
public class PayForGoldProductActivity extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.activity_pay_for_gold_product_toolbar)
    Toolbar activityPayForGoldProductToolbar;
    @BindView(R.id.activity_pay_for_gold_product_tv_name)
    TextView activityPayForGoldProductTvName;
    @BindView(R.id.activity_pay_for_gold_product)
    LinearLayout activityPayForGoldProduct;
    @BindView(R.id.activity_pay_for_gold_product_submitbutton)
    Button activityPayForGoldProductSubmitbutton;
    @BindView(R.id.activity_pay_for_gold_product_tv_ac)
    TextView activityPayForGoldProductTvAc;
    @BindView(R.id.activity_pay_for_gold_product_tv_acdtail)
    TextView activityPayForGoldProductTvAcdtail;
    @BindView(R.id.activity_pay_for_gold_product_tv_detail)
    TextView activityPayForGoldProductTvDetail;
    private Double product_accrual;
    private String product_accrual_detail;
    private String product_commodity_name;
    private String product_commodity_detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_for_gold_product);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        initIntent();
        new DToolbar(this, R.id.activity_pay_for_gold_product_toolbar);
    }

    private void initIntent() {
        Intent mIntent = getIntent();
        product_accrual = mIntent.getDoubleExtra("Pay_For_Product_Accrual", 0);
        product_accrual_detail = mIntent.getStringExtra("Pay_For_Product_Accrual_Detail");
        product_commodity_name = mIntent.getStringExtra("Pay_For_Product_Commodity_Name");
        product_commodity_detail = mIntent.getStringExtra("Pay_For_Product_Commodity__Detail");
        activityPayForGoldProductTvAc.setText(product_accrual.toString());
        activityPayForGoldProductTvAcdtail.setText(product_accrual_detail);
        activityPayForGoldProductTvName.setText(product_commodity_name);
        activityPayForGoldProductTvDetail.setText(product_commodity_detail);
        activityPayForGoldProductSubmitbutton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_pay_for_gold_product_submitbutton:
                Intent intent = new Intent(PayForGoldProductActivity.this, AllTheIndentActivity.class);
                InsuranceBean bean = new InsuranceBean();
                bean.setAccrual(product_accrual);
                bean.setAccrual_detail(product_accrual_detail);
                bean.setCommodity_detail(product_commodity_name);
                bean.setCommodity_name(product_commodity_detail);
                intent.putExtra("Serializable", bean);
                //把数据存储进数据库
                startActivity(intent);

                finish();
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}
