package com.example.yasin.golduniversecowry.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.example.yasin.golduniversecowry.Adapter.zhxRecycleAdpater;
import com.example.yasin.golduniversecowry.R;
import com.zhy.adapter.recyclerview.MultiItemTypeAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yasin on 2017/2/20.
 */
//第二个界面
public class LoanFragment extends Fragment {
    private View view;
    private Button button1;
    private EditText checkedTextView;
    private Context context;
    private RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_loan,container,false);
        button1=(Button) view.findViewById(R.id.contactsfragment_button1_id);
        checkedTextView= (EditText) view.findViewById(R.id.contactsfragment_checkedTextView1_id);
        context=getContext();
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent002=new Intent();
                Log.e("Tag",checkedTextView.getText().toString());
                intent002.setAction("com.example.yasin.golduniversecowry.fragment");
                context.sendBroadcast(intent002);
            }
        });
        init();

        return view;

    }

    private void init() {
        List<String> mdatas=new ArrayList<>();
        mdatas.add("zhanghangxiang1");
        mdatas.add("zhanghangxiang2");
        mdatas.add("zhanghangxiang3");
        mdatas.add("zhanghangxiang4");
        mdatas.add("zhanghangxiang5");
        mdatas.add("zhanghangxiang6");
        recyclerView = (RecyclerView) view.findViewById(R.id.fragment_loan_recyclerview_zhxtest);
        LinearLayoutManager layoutManager=new LinearLayoutManager(view.getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(new zhxRecycleAdpater(this.getContext(),R.layout.zhx_item_list,mdatas));
        MultiItemTypeAdapter adapter = new MultiItemTypeAdapter(this.getContext(),mdatas);
    }

    //广播
    private IntentFilter intentFilter;
}
