package com.example.yasin.golduniversecowry;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

//引导页
public class GuidanceActivity extends AppCompatActivity {
    private ViewPager viewpage1;
    private Button bt1;
    private int photo[];
    private List<Fragment> list=new ArrayList<>();
    private List<Fragment> gedata(){
        return list;
    }
    private SharedPreferences sp;//内置数据库
    private SharedPreferences.Editor editor;//数据库编辑器
    private boolean isSPFirst=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guidance);
        sp=getSharedPreferences("spinfo",MODE_PRIVATE);//数据库表名
        isSPFirst=sp.getBoolean("isSPFirst",true);//获取条目名的布尔值
        editor=getSharedPreferences("spinfo",MODE_PRIVATE).edit();//获取数据库的表里的属性和对应修饰符对应的修改者
        if(isSPFirst){
            editor.putBoolean("isSPFirst",false);//设置布尔值后应用
            editor.apply();
            init();
        }else{
            gotoMainActivity();
        }
    }
    private void gotoMainActivity(){//抽取出来的方法
        Intent intent=new Intent(GuidanceActivity.this,MainActivityDdy.class);
        startActivity(intent);
        finish();
    }
    private void init() {
        photo=new int[]{R.mipmap.newpage1,R.mipmap.newpage2};
        bt1= (Button) findViewById(R.id.guidance_button1);
        viewpage1=(ViewPager)findViewById(R.id.guidance_page_first);
        viewpage1.setAdapter(new ViewPager2());
        viewpage1.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {//设置pageview的滑动监听器
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageSelected(int position) {//设置页面滑动时的方法，position是当前页面
            if(position==1){
                bt1.setVisibility(View.VISIBLE);//设置按钮可见
            }else {
                bt1.setVisibility(View.INVISIBLE);
            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    });
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               gotoMainActivity();
            }
        });//按钮的监视器
    }

    private class ViewPager2 extends PagerAdapter {
        @Override
        public int getCount() {
            return photo.length;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {//实例化对象
            ImageView imageView = new ImageView(GuidanceActivity.this);
            imageView.setImageResource(photo[position]);
            container.addView(imageView);
            return imageView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view==object;
        }
    }
}
