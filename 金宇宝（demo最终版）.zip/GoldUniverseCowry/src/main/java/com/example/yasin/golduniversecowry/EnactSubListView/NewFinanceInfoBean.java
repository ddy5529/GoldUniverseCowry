package com.example.yasin.golduniversecowry.EnactSubListView;

/**
 * Created by Yasin on 2017/3/18.
 */

public class NewFinanceInfoBean {
    //id，标题，事件,时间，来源
    public int NFIid;
    public String NFItitle;
    public String NFIcontent;
    public String NFItime;
    public String NFIfrom;
}
