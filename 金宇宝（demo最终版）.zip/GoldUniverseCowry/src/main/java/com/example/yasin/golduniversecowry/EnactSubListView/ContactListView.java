package com.example.yasin.golduniversecowry.EnactSubListView;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by Yasin on 2017/2/22.
 */

public class ContactListView  {//这是用于作为首页好友的 信息的 Listview的 适配器的 泛型的 类（用五个词来修饰一个词  v^v ）
    //名字，头像，信息，时间
    private String name;
    private int friendsphoto;
    private String message;
    private  String date;

    public ContactListView(String name, int friendsphoto, String message, String date) {

        this.name = name;
        this.friendsphoto = friendsphoto;
        this.message = message;
        this.date = date;
    }


    public String getName() {
        return name;
    }

    public int getFriendsphoto() {
        return friendsphoto;
    }

    public String getMessage() {
        return message;
    }

    public String getDate() {
        return date;
    }
}
