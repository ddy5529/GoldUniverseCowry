package com.example.yasin.golduniversecowry.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


import com.example.yasin.golduniversecowry.Activitys.UserRegistActivity;
import com.example.yasin.golduniversecowry.Adapter.FriendInfoRVA;
import com.example.yasin.golduniversecowry.Adapter.MoneyChangerRVA;
import com.example.yasin.golduniversecowry.Adapter.NewFinanceInfoRVA;
import com.example.yasin.golduniversecowry.Adapter.ProductInfoRVA;
import com.example.yasin.golduniversecowry.EnactSubListView.FriendInfoBean;
import com.example.yasin.golduniversecowry.EnactSubListView.MoneyChangerBean;
import com.example.yasin.golduniversecowry.EnactSubListView.NewFinanceInfoBean;
import com.example.yasin.golduniversecowry.EnactSubListView.ProductInfoBean;
import com.example.yasin.golduniversecowry.OkWebConnection;
import com.example.yasin.golduniversecowry.R;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Yasin on 2017/2/20.
 */
//第三个界面
public class FundFragment extends Fragment {
    private Button button4,button3;
    private View view;
    private Context context;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_fund,container,false);
        context=view.getContext();
//        Log.e("Tag",context.toString()+"————这是推荐碎片的context");
        initButton();
        initFruits();
        return view;
    }

    private void initButton(){
        button3= (Button) view.findViewById(R.id.button0003);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(context, OkWebConnection.class);
                startActivity(intent1);
            }
        });
        button4=(Button)view.findViewById(R.id.button0004);
//        Log.e("Tag",context.toString()+"---------这是FindFragment的核心");
        button4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,UserRegistActivity.class);
                startActivity(intent);
            }
        });

    }
    private void initFruits(){
//        Log.e("Tag","创建RecyclerView...");
        RecyclerView recyclerView1=(RecyclerView)view.findViewById(R.id.fundfragment_recycler_view_MoneyChangeInfo_id);
        RecyclerView recyclerView2= (RecyclerView) view.findViewById(R.id.fundfragment_recycler_view_friendInfo_id);
        RecyclerView recyclerView3= (RecyclerView) view.findViewById(R.id.fundfragment_recycler_view_NewFinanceInfo_id);
        RecyclerView recyclerView4= (RecyclerView) view.findViewById(R.id.fundfragment_recycler_view_ProductInfo_id);
//        Log.e("Tag","创建布局管理...");
        LinearLayoutManager linearLayoutManager1=new LinearLayoutManager(context);
        recyclerView1.setLayoutManager(linearLayoutManager1);
        LinearLayoutManager linearLayoutManager2=new LinearLayoutManager(context);
        recyclerView2.setLayoutManager(linearLayoutManager2);
        LinearLayoutManager linearLayoutManager3=new LinearLayoutManager(context);
        recyclerView3.setLayoutManager(linearLayoutManager3);
        LinearLayoutManager linearLayoutManager4=new LinearLayoutManager(context);
        recyclerView4.setLayoutManager(linearLayoutManager4);


        //bean的初始化，可以在这里用类来传bean
        /*
        * 服务器发送一个json数据，
        * 用一个jsonobject存储4个jsonarray解析后生成四个jsonArray数组，每个数组对应一个list_bean,每个bean中存储一个类型的结构数据
        * 用一个类来做这件事情，用okhttp接收网页数据后，传数据出来，用一个jsonobject接受数据，然后生成4个list,
        * 把四个list作为成员变量，都设置为private 然后设置get方法，用于获取数据
        * */
//        Log.e("Tag","创建javabean...");
        MoneyChangerBean moneyChangerBean=new MoneyChangerBean();
        FriendInfoBean friendInfoBean=new FriendInfoBean();
        NewFinanceInfoBean newFinanceInfoBean=new NewFinanceInfoBean();
        ProductInfoBean productInfoBean=new ProductInfoBean();

        //对添加进4个适配器的list 和bean进行初始化和赋值，在这里进行数据的加载
        List<MoneyChangerBean> changerBeanList=new ArrayList<>();
        //时间，地点，时间，金额
        moneyChangerBean.mctime="mctime";
        moneyChangerBean.mclocation="mclocation";
        moneyChangerBean.mcevent="mcevent";
        moneyChangerBean.mcmoney="mcnoney";
        changerBeanList.add(moneyChangerBean);
        List<FriendInfoBean> friendInfoBeanList=new ArrayList<>();
        //名字，时间，信息，照片
        friendInfoBean.friendname="friendname";
        friendInfoBean.friendtime="friendtime";
        friendInfoBean.friendinfo="friendinfo";
        friendInfoBean.friendphoto="friendphoto";
        friendInfoBeanList.add(friendInfoBean);
        List<NewFinanceInfoBean> newFinanceInfoBeanList=new ArrayList<>();
        //标题，内容，时间，来源
        newFinanceInfoBean.NFIid=0;
        newFinanceInfoBean.NFItitle="nfititle";
        newFinanceInfoBean.NFIcontent="nficontent";
        newFinanceInfoBean.NFItime="nfitime";
        newFinanceInfoBean.NFIfrom="nfifrom";
        newFinanceInfoBeanList.add(newFinanceInfoBean);
        List<ProductInfoBean> productInfoBeanList=new ArrayList<>();
        //照片，名字，信息
        productInfoBean.PDIimage="pdlimage";
        productInfoBean.PDIname="pdiname";
        productInfoBean.PDIinfo="pdiinfo";
        productInfoBeanList.add(productInfoBean);
//        Log.e("Tag","适配数据完成");
        MoneyChangerRVA moneyChangerRVA=new MoneyChangerRVA(changerBeanList);
        FriendInfoRVA friendInfoRVA=new FriendInfoRVA(friendInfoBeanList);
        NewFinanceInfoRVA newFinanceInfoRVA=new NewFinanceInfoRVA(newFinanceInfoBeanList);
        ProductInfoRVA productInfoRVA=new ProductInfoRVA(productInfoBeanList);
//        Log.e("Tag","适配器初始化完成...");
        recyclerView1.setAdapter(moneyChangerRVA);
        recyclerView2.setAdapter(friendInfoRVA);
        recyclerView3.setAdapter(newFinanceInfoRVA);
        recyclerView4.setAdapter(productInfoRVA);
//        Log.e("Tag","适配器加载完成...");
    }


}
