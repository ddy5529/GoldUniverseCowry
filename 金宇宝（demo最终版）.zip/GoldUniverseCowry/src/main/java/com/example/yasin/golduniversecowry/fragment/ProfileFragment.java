package com.example.yasin.golduniversecowry.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yasin.golduniversecowry.Activitys.UserRegistActivity;
import com.example.yasin.golduniversecowry.Activitys.user.SetOperation;
import com.example.yasin.golduniversecowry.R;
import com.example.yasin.golduniversecowry.sql.MyDatabaseHelper;
import com.example.yasin.golduniversecowry.sql.UserDBManager;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Yasin on 2017/2/20.
 */
//第四个界面
public class ProfileFragment extends Fragment implements View.OnClickListener {
    @BindView(R.id.prpfile_iv_myIcons)
    ImageView prpfileIvMyIcons;
    @BindView(R.id.fragment_user_name)
    TextView fragmentUserName;
    @BindView(R.id.profile_tv_myMoney)
    TextView profileTvMyMoney;
    @BindView(R.id.linearlayout_business)
    LinearLayout linearlayoutBusiness;
    @BindView(R.id.profile_bt_01)
    Button profileBt01;
    @BindView(R.id.profile_bt_02)
    Button profileBt02;
    @BindView(R.id.profile_bt_03)
    Button profileBt03;
    @BindView(R.id.profile_bt_04)
    Button profileBt04;
    @BindView(R.id.profile_bt_05)
    Button profileBt05;
    @BindView(R.id.fragment_profiles_userLinearLayout)
    LinearLayout fragmentProfilesUserLinearLayout;
    @BindView(R.id.login_profiles_layout_tv_username)
    EditText loginProfilesLayoutTvUsername;
    @BindView(R.id.login_profiles_layout_tv_password)
    EditText loginProfilesLayoutTvPassword;
    @BindView(R.id.login_profiles_layout_bt_login)
    Button loginProfilesLayoutBtLogin;
    @BindView(R.id.login_profiles_layout_tv_forget)
    TextView loginProfilesLayoutTvForget;
    @BindView(R.id.login_profiles_layout_tv_more)
    TextView loginProfilesLayoutTvMore;
    @BindView(R.id.login_profiles_layout_RelativeLayout_id)
    RelativeLayout loginProfilesLayoutRelativeLayoutId;
    @BindView(R.id.login_profiles_layout_bt_regist)
    Button loginProfilesLayoutBtRegist;
    private View view;
    public static boolean isLogin = false;
    public static String pro_username ="";
    public static String pro_money ="";
    private Toast toast;

    public final static int select_showUI_first = 1;
    public final static int select_showUI_two = 2;
    private Cursor cursor;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_profiles, container, false);
        ButterKnife.bind(this, view);
        init();
        return view;
    }

    private void init() {
        initClick();
        //当触发点击后
        if (isLogin) {

            fragmentUserName.setText(pro_username);
            profileTvMyMoney.setText(pro_money);

            loginProfilesLayoutRelativeLayoutId.setVisibility(View.GONE);
            fragmentProfilesUserLinearLayout.setVisibility(View.VISIBLE);
        } else {
            loginProfilesLayoutRelativeLayoutId.setVisibility(View.VISIBLE);
            fragmentProfilesUserLinearLayout.setVisibility(View.GONE);
        }



    }

    //设置点击事件
    private void initClick() {
        loginProfilesLayoutBtLogin.setOnClickListener(this);
        loginProfilesLayoutBtRegist.setOnClickListener(this);
        loginProfilesLayoutTvForget.setOnClickListener(this);
        loginProfilesLayoutTvMore.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login_profiles_layout_bt_login:
                Log.e("Tag", " 账号输入的内容为： |" + loginProfilesLayoutTvUsername.getText().toString().trim()+"|");
                //账号密码验证
                //创建用户数据管理表员
                UserDBManager manager=new UserDBManager();
                //打开用户curse
                cursor = manager.returnUserTableCursor(this.getContext());
                String user_name= loginProfilesLayoutTvUsername.getText().toString().trim();
                String password= loginProfilesLayoutTvPassword.getText().toString().trim();
                Log.e("Tag",ProfileFragment.class+"|"+user_name+"|");
                if (cursor.moveToFirst()){
                    do {
                        Log.e("Tag","-----|"+ cursor.getString(cursor.getColumnIndex("username"))+"|-----");
                        if (user_name.equals(cursor.getString(cursor.getColumnIndex("username")))){
                            if (password.equals(cursor.getString(cursor.getColumnIndex("password")))){
                                toast = Toast.makeText(ProfileFragment.this.getContext(), "登陆中", Toast.LENGTH_SHORT);
                                toast.show();
                                isLogin = true;
                                pro_username= cursor.getString(cursor.getColumnIndex("username"));
                                fragmentUserName.setText(pro_username);
                                pro_money=String.valueOf(cursor.getFloat(cursor.getColumnIndex("money")));
                                profileTvMyMoney.setText(pro_money);
                                loginProfilesLayoutRelativeLayoutId.setVisibility(View.GONE);
                                fragmentProfilesUserLinearLayout.setVisibility(View.VISIBLE);
                                break;
                            }
                        }
                    }while (cursor.moveToNext());
                }
                break;
            case R.id.login_profiles_layout_bt_regist:
                Intent intent = new Intent(this.getContext(), UserRegistActivity.class);
                startActivity(intent);
                break;
            case R.id.login_profiles_layout_tv_forget:
                Intent intent1 = new Intent(this.getContext(), SetOperation.class);
                intent1.putExtra("operation", select_showUI_first);
                startActivity(intent1);
                break;
            case R.id.login_profiles_layout_tv_more:
                new AlertDialog.Builder(this.getContext())
                        .setTitle("")
                        .setItems(R.array.items,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String[] ary=getResources().getStringArray(R.array.items);
                                        Log.e("Tag"," current dialog click the string is : "+ary[which]);
//                                        dialog.dismiss();//销毁对话框
                                    }
                                })
                        .setNeutralButton("提交", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.e("Tag","alert ");
                            }
                        })
                        .show();
                break;
        }
    }
}
