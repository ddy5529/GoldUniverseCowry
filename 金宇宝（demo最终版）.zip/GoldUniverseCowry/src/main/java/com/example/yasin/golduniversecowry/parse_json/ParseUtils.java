package com.example.yasin.golduniversecowry.parse_json;

import com.example.yasin.golduniversecowry.EnactSubListView.MoneyChangerBean;
import com.example.yasin.golduniversecowry.web_connection.WebConnection;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;

/**
 * Created by Yasin on 2017/3/29.
 */

public class ParseUtils {

    private List<MoneyChangerBean> changerBeanList;

   /* public JSONObject getJsonObject(){
        return null;
    }*/
    public List<MoneyChangerBean> getMoneyChangerBeanList(){
        changerBeanList = new ArrayList<>();
        OkHttpUtils
                .get()
                .url("http://120.77.170.191/share/t1.txt")
                .build()
                .execute(new MyStringCallBack());
        return changerBeanList;
    }
    class MyStringCallBack extends StringCallback {

        @Override
        public void onError(Call call, Exception e, int id) {

        }

        @Override
        public void onResponse(String response, int id) {
            Gson gson=new Gson();
            MoneyChangerBean bean=gson.fromJson(response,MoneyChangerBean.class);
            changerBeanList.add(bean);
        }
    }
}
