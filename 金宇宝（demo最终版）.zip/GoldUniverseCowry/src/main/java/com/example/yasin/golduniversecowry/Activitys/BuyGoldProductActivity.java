package com.example.yasin.golduniversecowry.Activitys;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;

import com.example.yasin.golduniversecowry.R;
import com.example.yasin.golduniversecowry.ddy_toolbar.DToolbar;
import com.example.yasin.golduniversecowry.fragment.ProfileFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
//购买产品界面
public class BuyGoldProductActivity extends AppCompatActivity implements View.OnClickListener {


    @BindView(R.id.activity_buy_gold_product)
    TableLayout activityBuyGoldProduct;
    @BindView(R.id.activity_buy_gold_product_tv_Accrual)
    TextView activityBuyGoldProductTvAccrual;
    @BindView(R.id.activity_buy_gold_product_tv_Command)
    TextView activityBuyGoldProductTvCommand;
    @BindView(R.id.activity_buy_gold_product_tv_Accrual_Detail)
    TextView activityBuyGoldProductTvAccrualDetail;
    @BindView(R.id.activity_buy_gold_product_tv_Command_Detail)
    TextView activityBuyGoldProductTvCommandDetail;

    @BindView(R.id.activity_buy_gold_product_bt_calculator)
    Button activityBuyGoldProductBtCalculator;
    @BindView(R.id.activity_buy_gold_product_bt_letmebuy)
    Button activityBuyGoldProductBtLetmebuy;
    private String data_s2;
    private Double data_d;
    private String data_s1;
    private String data_s3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_gold_product);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        initToolbar();
        initIntent();
        iniButton();
    }

    private void iniButton() {
        activityBuyGoldProductBtLetmebuy.setOnClickListener(this);
    }

    private void initToolbar() {
        new DToolbar(this,R.id.activity_buy_gold_product_toolbar);
    }

    private void initIntent() {
        Intent intent = getIntent();
        data_d = intent.getDoubleExtra("Gold_Product_Accrual", 0);
        data_s1 = intent.getStringExtra("Gold_Product_Accrual_Detail");
        data_s2 = intent.getStringExtra("Gold_Product_Commodity_Name");
        data_s3 = intent.getStringExtra("Gold_Product_Commodity_Detail");
        Log.i("Tag", data_d.toString());
        activityBuyGoldProductTvAccrual.setText(String.valueOf(data_d));
        activityBuyGoldProductTvAccrualDetail.setText(data_s1);
        activityBuyGoldProductTvCommand.setText(data_s2);
        activityBuyGoldProductTvCommandDetail.setText(data_s3);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.activity_buy_gold_product_bt_letmebuy:
                if(ProfileFragment.isLogin) {
                    Intent mintent = new Intent(this, PayForGoldProductActivity.class);
                    mintent.putExtra("Pay_For_Product_Accrual",data_d);
                    mintent.putExtra("Pay_For_Product_Accrual_Detail", data_s1);
                    mintent.putExtra("Pay_For_Product_Commodity_Name", data_s2);
                    mintent.putExtra("Pay_For_Product_Commodity__Detail", data_s3);
                    startActivity(mintent);//启动跳转
                    finish();
                }else{
                    AlertDialog.Builder dialog=new AlertDialog.Builder(this);
                    dialog.setTitle("登陆失败");
                    dialog.setMessage("是否要跳转到登陆界面呢？");
                    dialog.setCancelable(true);
                    dialog.setPositiveButton("好的", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent=new Intent(BuyGoldProductActivity.this, LoginActivity.class);
                            startActivity(intent);
                        }
                    });
                    dialog.setNegativeButton("还是算了吧", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                       //nothing
                            dialog.cancel();
                        }
                    });
                    dialog.show();
                }
        }
    }
}
