package com.example.yasin.golduniversecowry.EnactSubListView;

/**
 * Created by Yasin on 2017/3/18.
 */

public class ProductInfoBean {
    //图片，名字，信息
    public String PDIimage;
    public String PDIname;
    public String PDIinfo;

}
